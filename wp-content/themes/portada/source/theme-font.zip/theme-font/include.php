<?php

/******************************************************************************/
/******************************************************************************/

require_once(plugin_dir_path(__FILE__).'define.php');

require_once(PLUGIN_THEME_FONT_CLASS_PATH.'TF.File.class.php');
require_once(PLUGIN_THEME_FONT_CLASS_PATH.'TF.Include.class.php');

TFInclude::includeFileFromDir(PLUGIN_THEME_FONT_CLASS_PATH);

/******************************************************************************/
/******************************************************************************/